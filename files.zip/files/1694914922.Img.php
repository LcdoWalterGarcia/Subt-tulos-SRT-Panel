  <?php
    // Obtén la URL de la vista previa del formulario
    if(isset($_POST['img'])){
        $img_url = $_POST['img'];
    }
    ?>
    <div id="previewImage">
        <?php
        // Muestra la imagen de vista previa si se proporciona una URL
        if (!empty($img_url)) {
            echo '<img_url src=https://image.tmdb.org/t/p/w300/6aNKD81RHR1DqUUa8kOZ1TBY1Lp.jpg"' . htmlspecialchars($img_url) . '" alt="Vista Previa" />';
        }
        ?>
    </div>