//Global variable
var http_arr = new Array();

function doUpload() {
	document.getElementById('progress-group').innerHTML = ''; //Reset the Progress-group
	document.getElementById('result').innerHTML = '';
	var files = document.getElementById('file').files;
	var checkEmpty = $('#file').val();
	if (checkEmpty != ''){
			$('#progress-group').css('display', 'block');
			for (i=0;i<files.length;i++) {
				uploadFile(files[i], i);
			}
	}
	return false;
}

function uploadFile(file, index) {
	var http = new XMLHttpRequest();
	http_arr.push(http);
	/** Initialize the process area **/
	//Div.Progress-group
	var ProgressGroup = document.getElementById('progress-group');
	//Div.Progress
	var Progress = document.createElement('div');
	Progress.className = 'progress';
	//Div.Progress-bar
	var ProgressBar = document.createElement('div');
	ProgressBar.className = 'progress-bar';
	//Div.Progress-text
	var ProgressText = document.createElement('div');
	ProgressText.className = 'progress-text';	
	//Add Div.Progress-bar and Div.Progress-text to Div.Progress
	Progress.appendChild(ProgressBar);
	Progress.appendChild(ProgressText);
	//Add Div.Progress and Div.Progress-bar to Div.Progress-group
	ProgressGroup.appendChild(Progress);


	//Variable supports speed calculations
	var oldLoaded = 0;
	var oldTime = 0;
	//Event capture process
	http.upload.addEventListener('progress', function(event) {	
		if (oldTime == 0) { //Set the previous time if zero.
			oldTime = event.timeStamp;
		}	
		//Initialize the necessary variables
		var fileName = file.name; //File name
		var fileLoaded = event.loaded; //How much load has been made
		var fileTotal = event.total; //Total amount of space to load
		var fileProgress = parseInt((fileLoaded/fileTotal)*100) || 0; //Processing process
		//Use variable
		ProgressBar.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Processcing...('+fileProgress+'%)';
		ProgressBar.style.width = fileProgress + '%';
		//Wait for data to return
		if (fileProgress == 100) {
			ProgressBar.addClass('progress-bar progress-bar-striped active').html('<i class="fa fa-spinner fa-spin"></i> Processcing...('+fileProgress+'%)');
		}
		oldTime = event.timeStamp; //Set time after execution of the process
		oldLoaded = event.loaded; //Set the received data
	}, false);
	

	//Begin Upload
	var data = new FormData();
	data.append('filename', file.name);
	data.append('file', file);
	http.open('POST', './upload.php', true);
	http.send(data);


	//Get the data returned
	http.onreadystatechange = function(event) {
		//Check the condition
		if (http.readyState == 4 && http.status == 200) {
			
			try { //JSON bug trap
				var server = JSON.parse(http.responseText);
				if (server.status) {
					ProgressBar.className += ' progress-bar-success'; //Add class Success
					ProgressBar.innerHTML = server.message; //Notification
					document.getElementById("result").innerHTML = server.result;
				} else {
					ProgressBar.className += ' progress-bar-danger'; //Add class Danger
					ProgressBar.innerHTML = server.message; //Notification
				}
			} catch (e) {
				ProgressBar.className += ' progress-bar-danger'; //Add class Danger
				ProgressBar.innerHTML = '<i class="fa fa-exclamation-triangle"></i> Something Went Wrong. Please Try Again!'; //Notification
			}
		}
		http.removeEventListener('progress'); //Quit event
	}
}
